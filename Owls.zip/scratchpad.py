""" This is the Scratchpad!
This file is not graded, but you can use it to test your code.

You can write and test your function in the Scratchpad, but make
sure to copy and paste it into the Unit Test file before checking
your answer. Remember to only copy and paste the function you want
to submit, not all of your tests.
"""

# Add your own tests here
def owl_count(text):
    text.lower()
    text.split()
    print("There are " + str(text.count("owl")) + " words that contained \"owl\".")
    print("They occured at indices: ")
    for c, value in enumerate(text, 1):
        print(c, value)
    
    return 0
    
text = input("Enter some text: ")
owl_count(text)